/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=15x15 food food.png 
 * Time-stamp: Wednesday 04/07/2021, 22:57:02
 * 
 * Image Information
 * -----------------
 * food.png 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FOOD_H
#define FOOD_H

extern const unsigned short food[225];
#define FOOD_SIZE 450
#define FOOD_LENGTH 225
#define FOOD_WIDTH 15
#define FOOD_HEIGHT 15

#endif

