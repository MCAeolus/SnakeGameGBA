/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 startup startup.png 
 * Time-stamp: Wednesday 04/07/2021, 01:12:10
 * 
 * Image Information
 * -----------------
 * startup.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STARTUP_H
#define STARTUP_H

extern const unsigned short startup[38400];
#define STARTUP_SIZE 76800
#define STARTUP_LENGTH 38400
#define STARTUP_WIDTH 240
#define STARTUP_HEIGHT 160

#endif

